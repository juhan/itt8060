﻿namespace mastermind

open System

open Android.App
open Android.Content
open Android.OS
open Android.Runtime
open Android.Views
open Android.Widget
open Mastermind

[<Activity (Label = "mastermind", MainLauncher = true, Icon = "@mipmap/icon")>]
type MainActivity () =
    inherit Activity ()

    //let mutable count:int = 1
    let mutable state : State = Start

    override this.OnCreate (bundle) =

        base.OnCreate (bundle)

        // Set our view from the "main" layout resource
        this.SetContentView (Resource_Layout.Main)

        // Get our button from the layout resource, and attach an event to it
        let buttonSubmit = this.FindViewById<Button>(Resource_Id.buttonSubmit)
        let textEdit = this.FindViewById<EditText>(Resource_Id.editText)
        let textView = this.FindViewById<TextView>(Resource_Id.textView)
        let buttonReset = this.FindViewById<Button>(Resource_Id.buttonReset)

        buttonSubmit.Click.Add (fun args -> 
            let getInput (cont : (String * Code) -> unit) : unit =
                let input = textEdit.Text
                let code = tryParseCode input
                match code with    
                | Some xs -> 
                    textEdit.Text <- ""
                    state <- next state (Submit xs)
                    cont (input,xs)
                | None -> ()

            match state with
            | Start -> 
                getInput (fun _ -> buttonSubmit.Text <- "Make a guess")
            | Playing (i , f) ->
                getInput (fun (s,xs) -> 
                    textView.Text <- textView.Text + "\nGuess: " + s + " - " + printHint (f xs))
            | _ -> () // shouldn't be in win or lose state when we click

            // check if we've advanced to  win or lose state
            match state with
            | Win -> 
               textView.Text <- textView.Text + "\nYou win!"
               buttonSubmit.Enabled <- false
            | Lose ->
               textView.Text <- textView.Text + "\nYou lose!"
               buttonSubmit.Enabled <- false
            | _ -> () // if haven't won or lost then do nothing
        )

        buttonReset.Click.Add (fun args -> 
            buttonSubmit.Text <- "Enter a secret code"
            buttonSubmit.Enabled <- true
            textView.Text <- ""
            state <- Start
        )
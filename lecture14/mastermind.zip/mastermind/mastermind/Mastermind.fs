﻿

namespace mastermind
open System

module Mastermind = 
    type Color = Blue | Green | Red | Purple
    type Code = list<Color>
    type Hint = RightPlace | WrongPlace | Missing
    type Hints = list<Hint>
    type Checker = Code -> Hints

    let check (code : Code)(guess : Code) : Hints =
        let rightPlaces = List.map2 (fun x y -> x = y) code guess
        let wrongPlace g = List.exists (fun c -> g = c) code
        let wrongPlaces = List.map wrongPlace guess
        let test b1 b2 =
            match (b1,b2) with
                | (true,_) -> RightPlace
                | (_,true) -> WrongPlace
                | _        -> Missing 
        List.map2 test rightPlaces wrongPlaces

    let printHint (xs : Hints) : string =
        let help x =
            match x with
            | RightPlace  -> "*"
            | WrongPlace -> "-"
            | Missing       -> "."
        String.concat "" (List.map help xs)

    let tryParseColor (c : char) : option<Color> =
        match c with
            | 'R'|'r' -> Some Red
            | 'G'|'g' -> Some Green
            | 'B'|'b' -> Some Blue
            | 'P'|'p' -> Some Purple
            | _   -> None

    // couldn't find this in the library
    let rec sequence (xs : list<option<'a>>) : option<list<'a>> =
        match xs with
            | [] -> Some []
            | None::tl -> None
            | Some x::tl ->
                match sequence tl with
                    | Some xs -> Some (x::xs)
                    | None    -> None

    let tryParseCode (s : string) : option<Code> =
      let xs = s |> Seq.map tryParseColor |> Seq.toList
      if xs.Length = 4 then sequence xs else None

    // did we win?
    let win (hs : Hints) : bool = List.forall (fun x -> x = RightPlace) hs

    type State = Start | Playing of int * Checker | Win | Lose
    type Command = Reset | Submit of Code

    let next (s : State)(c : Command) : State =
        match c with
            | Reset -> Start
            | Submit code ->
                match s with
                    | Start -> Playing (8 , check code)
                    | Playing (i , f) ->
                        if win (f code) then // we won
                            Win
                        elif i <= 1 then // it was our last chance so we lost
                            Lose
                        else // continue
                          Playing (i - 1, f)
                     | Win  -> Win // we're stuck
                     | Lose -> Lose // we're stuck
